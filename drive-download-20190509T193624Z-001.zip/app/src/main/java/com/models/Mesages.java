package com.models;

public class Mesages {
    String texto;


    @Override
    public String toString(){
        return texto;
    }
    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }
}
